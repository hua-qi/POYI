const envList = [{"envId":"cloud1-4gvnm4k7b5bb273b","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}