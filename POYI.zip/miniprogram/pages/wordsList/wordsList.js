Page({
  data: {
    itemData: [{
        "type": "CET4",
        "title": "英语四级单词",
        "imgUrl": "cloud://cloud1-4gvnm4k7b5bb273b.636c-cloud1-4gvnm4k7b5bb273b-1307703970/破译英语图片/CET4.png"
      },
      {
        "type": "CET6",
        "title": "英语六级单词",
        "imgUrl": "cloud://cloud1-4gvnm4k7b5bb273b.636c-cloud1-4gvnm4k7b5bb273b-1307703970/破译英语图片/CET6.png"
      },
      {
        "type": "TEM4",
        "title": "英语专业四级单词",
        "imgUrl": "cloud://cloud1-4gvnm4k7b5bb273b.636c-cloud1-4gvnm4k7b5bb273b-1307703970/破译英语图片/TEM4.png"
      },
      {
        "type": "TEM8",
        "title": "英语专业八级单词",
        "imgUrl": "cloud://cloud1-4gvnm4k7b5bb273b.636c-cloud1-4gvnm4k7b5bb273b-1307703970/破译英语图片/TEM8.png"
      },
    ]
  },

})